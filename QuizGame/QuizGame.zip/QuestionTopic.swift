
import Foundation

enum QuestionTopic: String, CaseIterable {
    case film = "FILM"
    case nyelv = "NYELV"
    case földrajz = "FÖLDRAJZ"
    case zene = "ZENE"
    case történelem = "TÖRTÉNELEM"
    case irodalom = "IRODALOM"
    case általános = "ÁLTALÁNOS"
    case sport = "SPORT"
    case tudomány = "TUDOMÁNY"
    case képzőművészet = "KÉPZŐMŰVÉSZET"
    case technika = "TECHNIKA"
    case biológia = "BIOLÓGIA"
    case magyarorszag = "MAGYARORSZÁG"
    case konyha = "KONYHA"
    case vallás = "VALLÁS"
    case játék = "JÁTÉK"
    case országok = "ORSZÁGOK"
    case építészet = "ÉPÍTÉSZET"
    case színház = "SZÍNHÁZ"
    case opera = "OPERA"
    case művészet = "MŰVÉSZET"
    case other = "OTHER"
}

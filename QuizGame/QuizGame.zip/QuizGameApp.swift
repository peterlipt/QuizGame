//
//  QuizGameApp.swift
//  QuizGame
//
//  Created by Péter Lipták on 2025. 03. 31..
//

import SwiftUI

@main
struct QuizGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
